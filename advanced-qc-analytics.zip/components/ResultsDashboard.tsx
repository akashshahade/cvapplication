
import React from 'react';
import { SpoutMetadata, Metric, Severity } from '../types';
import { AlertCircle, CheckCircle2, ShieldCheck, TrendingUp, Sparkles } from 'lucide-react';
import Charts from './Charts';

interface Props {
  metadata: SpoutMetadata;
  metrics: Metric[];
  aiInsight: string;
}

const ResultsDashboard: React.FC<Props> = ({ metadata, metrics, aiInsight }) => {
  const overallVerdict = metrics.some(m => m.status === 'FAIL') ? 'FAIL' : 'PASS';
  const confidence = metrics.find(m => m.parameter === 'Confidence Score')?.measured || '0%';

  return (
    <div className="space-y-8 pb-12">
      {/* Verdict Banner */}
      <div className={`w-full p-8 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl ${
        overallVerdict === 'PASS' 
          ? 'bg-gradient-to-r from-green-600 to-green-500 text-white' 
          : 'bg-gradient-to-r from-red-600 to-red-500 text-white'
      }`}>
        <div className="flex items-center gap-6">
          <div className="w-20 h-20 bg-white/20 rounded-2xl flex items-center justify-center">
            {overallVerdict === 'PASS' 
              ? <ShieldCheck size={48} strokeWidth={1.5} /> 
              : <AlertCircle size={48} strokeWidth={1.5} />
            }
          </div>
          <div>
            <h2 className="text-4xl font-bold tracking-tight uppercase">{overallVerdict}</h2>
            <p className="text-white/80 font-medium mt-1">
              {overallVerdict === 'PASS' 
                ? 'Insulator spout meets all quality standards.' 
                : 'Defect thresholds exceeded. Rectification required.'
              }
            </p>
          </div>
        </div>
        <div className="text-center md:text-right bg-black/10 px-6 py-4 rounded-2xl backdrop-blur-sm">
          <p className="text-sm font-semibold text-white/70 uppercase">Confidence</p>
          <p className="text-3xl font-black">{confidence}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white dark:bg-dark-lighter p-6 rounded-3xl border dark:border-gray-800 shadow-sm">
            <h3 className="text-lg font-bold mb-6 flex items-center gap-2 dark:text-white">
              <TrendingUp size={20} className="text-brand" /> Detailed Defect Metrics
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left text-xs text-gray-400 uppercase tracking-widest border-b dark:border-gray-800">
                    <th className="pb-4 font-semibold">Parameter</th>
                    <th className="pb-4 font-semibold">Measured</th>
                    <th className="pb-4 font-semibold">Threshold</th>
                    <th className="pb-4 font-semibold">Status</th>
                    <th className="pb-4 font-semibold">Severity</th>
                  </tr>
                </thead>
                <tbody className="divide-y dark:divide-gray-800">
                  {metrics.map((m, i) => (
                    <tr key={i} className="group hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                      <td className="py-4 font-medium dark:text-white">{m.parameter}</td>
                      <td className="py-4 font-mono dark:text-white">{m.measured}</td>
                      <td className="py-4 text-gray-500 dark:text-gray-300 text-sm">{m.threshold}</td>
                      <td className="py-4">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black tracking-tight ${
                          m.status === 'PASS' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                        }`}>
                          {m.status === 'PASS' ? <CheckCircle2 size={10} /> : <AlertCircle size={10} />}
                          {m.status}
                        </span>
                      </td>
                      <td className="py-4">
                        <SeverityBadge severity={m.severity} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-brand/5 dark:bg-brand/10 p-8 rounded-3xl border border-brand/20">
            <div className="flex items-center gap-2 mb-4 text-brand">
              <Sparkles size={24} />
              <h3 className="text-lg font-bold">Intelligent Summary</h3>
            </div>
            {aiInsight ? (
              <div className="prose prose-sm dark:prose-invert max-w-none text-gray-700 dark:text-gray-200 leading-relaxed">
                {aiInsight.split('\n').map((para, i) => (
                  <p key={i} className="mb-2">{para}</p>
                ))}
              </div>
            ) : (
              <div className="animate-pulse space-y-2">
                <div className="h-4 bg-gray-200 dark:bg-gray-800 rounded w-3/4"></div>
                <div className="h-4 bg-gray-200 dark:bg-gray-800 rounded w-full"></div>
                <div className="h-4 bg-gray-200 dark:bg-gray-800 rounded w-5/6"></div>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-white dark:bg-dark-lighter p-6 rounded-3xl border dark:border-gray-800 shadow-sm">
            <h3 className="text-lg font-bold mb-6 dark:text-white">Inspection Metadata</h3>
            <div className="space-y-4">
              <MetaRow label="Serial Number" value={metadata.serialNo} />
              <MetaRow label="Batch ID" value={metadata.batchId} />
              <MetaRow label="Operator" value={metadata.operator} />
              <MetaRow label="Scan Date" value={metadata.scanDate} />
            </div>
          </div>

          <Charts metrics={metrics} />
        </div>
      </div>
    </div>
  );
};

const SeverityBadge = ({ severity }: { severity: Severity }) => {
  const styles = {
    [Severity.OK]: 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300',
    [Severity.WARNING]: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-500',
    [Severity.CRITICAL]: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-500'
  };
  return (
    <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${styles[severity]}`}>
      {severity}
    </span>
  );
};

const MetaRow = ({ label, value }: { label: string, value: string }) => (
  <div className="flex justify-between items-center py-2 border-b dark:border-gray-800 last:border-0">
    <span className="text-sm text-gray-500 dark:text-gray-400">{label}</span>
    <span className="text-sm font-semibold dark:text-white">{value}</span>
  </div>
);

export default ResultsDashboard;
