
import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
  PieChart, Pie,
  RadarChart, PolarGrid, PolarAngleAxis, Radar
} from 'recharts';
import { Metric } from '../types';

interface Props {
  metrics: Metric[];
}

const Charts: React.FC<Props> = ({ metrics }) => {
  // Crack Geometry Data (Mock Regions)
  const crackData = [
    { region: 'Base', length: 1.2 },
    { region: 'Neck', length: 1.84 },
    { region: 'Body', length: 0.9 },
    { region: 'Rim', length: 0.4 },
  ];

  // Porosity Pie Data
  const porosityVal = parseFloat(metrics.find(m => m.parameter === 'Porosity Volume Fraction')?.measured || '0');
  const pieData = [
    { name: 'Porosity', value: porosityVal, color: '#007AC2' },
    { name: 'Dense Material', value: 100 - porosityVal, color: '#E5E7EB' },
  ];

  // Radar Data for Tilt
  const radarData = [
    { subject: 'X-Axis', A: 2.1, fullMark: 5 },
    { subject: 'Y-Axis', A: 1.8, fullMark: 5 },
    { subject: 'Z-Axis', A: 1.2, fullMark: 5 },
    { subject: 'Roll', A: 0.8, fullMark: 5 },
    { subject: 'Pitch', A: 2.5, fullMark: 5 },
  ];

  return (
    <div className="space-y-6">
      {/* Crack Geometry Bar */}
      <div className="bg-white dark:bg-dark-lighter p-6 rounded-3xl border dark:border-gray-800 shadow-sm">
        <h4 className="text-sm font-bold text-gray-400 uppercase mb-4">Crack Length by Region (mm)</h4>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={crackData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
              <XAxis dataKey="region" axisLine={false} tickLine={false} tick={{fontSize: 12}} />
              <YAxis hide domain={[0, 2.5]} />
              <Tooltip 
                cursor={{fill: 'transparent'}}
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
              />
              <Bar dataKey="length" radius={[4, 4, 0, 0]}>
                {crackData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.length > 1.5 ? '#F43F5E' : '#007AC2'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Porosity Donut */}
      <div className="bg-white dark:bg-dark-lighter p-6 rounded-3xl border dark:border-gray-800 shadow-sm">
        <h4 className="text-sm font-bold text-gray-400 uppercase mb-4">Porosity Distribution</h4>
        <div className="h-48 relative">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={pieData}
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <span className="text-2xl font-black">{porosityVal}%</span>
            <span className="text-[10px] text-gray-400 font-bold uppercase">Volume</span>
          </div>
        </div>
      </div>

      {/* Mesh Tilt Radar */}
      <div className="bg-white dark:bg-dark-lighter p-6 rounded-3xl border dark:border-gray-800 shadow-sm">
        <h4 className="text-sm font-bold text-gray-400 uppercase mb-4">Mesh Axis Tilt (°)</h4>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
              <PolarGrid stroke="#f0f0f0" />
              <PolarAngleAxis dataKey="subject" tick={{fontSize: 10}} />
              <Radar
                name="Tilt"
                dataKey="A"
                stroke="#007AC2"
                fill="#007AC2"
                fillOpacity={0.4}
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Charts;
