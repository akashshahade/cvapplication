
import React from 'react';
import { 
  Settings, 
  Info, 
  Database, 
  RotateCcw,
  Cpu
} from 'lucide-react';
import { HISTORY_ITEMS } from '../constants';

interface SidebarProps {
  isOpen: boolean;
  toggle: () => void;
  currentStage: string;
  onReset: () => void;
  onOpenThresholds: () => void;
  onOpenReleaseNotes: () => void;
  onOpenModelHealth: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  isOpen, 
  currentStage, 
  onReset, 
  onOpenThresholds, 
  onOpenReleaseNotes,
  onOpenModelHealth
}) => {
  return (
    <aside className={`
      ${isOpen ? 'translate-x-0 w-72' : '-translate-x-full w-0'}
      fixed md:relative z-40 h-full transition-all duration-300 ease-in-out border-r
      bg-white dark:bg-dark-lighter dark:border-gray-800 border-gray-200 overflow-hidden flex flex-col
    `}>
      <div className="p-6 border-b dark:border-gray-800 border-gray-100">
        <div className="flex items-center gap-2 mb-6">
          <img 
            src="https://upload.wikimedia.org/wikipedia/commons/2/2b/Eaton_Corporation_logo.svg" 
            alt="Eaton Logo" 
            className="h-8 transition-all" 
          />
        </div>
        
        <button 
          onClick={onReset}
          disabled={currentStage === 'form'}
          className="w-full flex items-center justify-center gap-2 py-2 px-4 rounded-lg bg-gray-100 dark:bg-gray-800 dark:text-gray-300 text-gray-700 font-medium hover:bg-brand hover:text-white dark:hover:bg-brand dark:hover:text-white transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <RotateCcw size={16} />
          New Inspection
        </button>
      </div>

      <nav className="flex-1 overflow-y-auto p-4 space-y-8">
        <div>
          <h3 className="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider mb-4">Inspection History</h3>
          <div className="space-y-1">
            {HISTORY_ITEMS.map(item => (
              <div key={item.id} className="group p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors cursor-pointer flex justify-between items-center">
                <div className="min-w-0">
                  <p className="text-sm font-semibold dark:text-white truncate">{item.id}</p>
                  <p className="text-xs text-gray-400">{item.date}</p>
                </div>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold flex-shrink-0 ${
                  item.verdict === 'PASS' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                }`}>
                  {item.verdict}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider mb-4">System Utilities</h3>
          <ul className="space-y-1">
            <SidebarItem 
              icon={<Settings size={18} />} 
              label="Threshold Config" 
              onClick={(e) => { e.preventDefault(); onOpenThresholds(); }}
            />
            <SidebarItem icon={<Database size={18} />} label="Batch Analytics" />
            <SidebarItem 
              icon={<Cpu size={18} />} 
              label="Model Health" 
              onClick={(e) => { e.preventDefault(); onOpenModelHealth(); }}
            />
            <SidebarItem 
              icon={<Info size={18} />} 
              label="Release Notes" 
              badge="v1.0" 
              onClick={(e) => { e.preventDefault(); onOpenReleaseNotes(); }}
            />
          </ul>
        </div>
      </nav>

      <div className="p-4 bg-gray-50 dark:bg-gray-900 mt-auto">
        <div className="flex items-center gap-3 p-3 rounded-xl border dark:border-gray-800 bg-white dark:bg-dark-lighter">
          <div className="w-10 h-10 rounded-full bg-brand/10 flex items-center justify-center text-brand font-bold text-xs flex-shrink-0">
            AS
          </div>
          <div className="min-w-0">
            <p className="text-sm font-bold truncate dark:text-white">Akash Shahade</p>
            <p className="text-xs text-gray-400 truncate">QC Lead Engineer</p>
          </div>
        </div>
      </div>
    </aside>
  );
};

const SidebarItem = ({ 
  icon, 
  label, 
  badge, 
  onClick 
}: { 
  icon: React.ReactNode, 
  label: string, 
  badge?: string,
  onClick?: (e: React.MouseEvent) => void
}) => (
  <li>
    <a 
      href="#" 
      onClick={onClick}
      className="flex items-center justify-between p-3 rounded-lg text-gray-600 dark:text-gray-300 hover:text-brand dark:hover:text-brand hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
    >
      <div className="flex items-center gap-3">
        {icon}
        <span className="text-sm font-medium">{label}</span>
      </div>
      {badge && <span className="text-[10px] bg-brand/10 text-brand px-1.5 py-0.5 rounded-md font-bold">{badge}</span>}
    </a>
  </li>
);

export default Sidebar;
