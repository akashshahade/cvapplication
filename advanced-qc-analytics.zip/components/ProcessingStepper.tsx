
import React from 'react';
import { PipelineStep } from '../types';
import { CheckCircle2, Loader2, Circle } from 'lucide-react';

interface Props {
  steps: PipelineStep[];
  activeIndex: number;
}

const ProcessingStepper: React.FC<Props> = ({ steps, activeIndex }) => {
  return (
    <div className="space-y-4">
      {steps.map((step, idx) => (
        <div 
          key={step.id} 
          className={`flex items-center gap-4 p-4 rounded-xl border transition-all duration-300 ${
            idx === activeIndex 
              ? 'border-brand bg-brand/5 scale-[1.02] shadow-sm' 
              : step.status === 'completed'
                ? 'border-green-200 bg-green-50 dark:bg-green-900/10 dark:border-green-900/20'
                : 'border-gray-100 dark:border-gray-800 opacity-60'
          }`}
        >
          <div className="flex-shrink-0">
            {step.status === 'completed' && <CheckCircle2 className="text-green-500" size={24} />}
            {step.status === 'processing' && <Loader2 className="text-brand animate-spin" size={24} />}
            {step.status === 'pending' && <Circle className="text-gray-300" size={24} />}
          </div>
          
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <h4 className="font-bold">{step.label}</h4>
              <span className="text-[10px] font-mono bg-gray-100 dark:bg-gray-800 px-2 py-0.5 rounded text-gray-500">
                {step.method}
              </span>
            </div>
            {idx === activeIndex && (
              <div className="mt-2 h-1 w-full bg-gray-200 dark:bg-gray-800 rounded-full overflow-hidden">
                <div className="h-full bg-brand animate-[loading_1s_ease-in-out_infinite]" style={{ width: '40%' }}></div>
              </div>
            )}
          </div>

          <div className="text-xs font-medium uppercase tracking-wider">
            {step.status === 'completed' ? <span className="text-green-600">Done</span> : 
             step.status === 'processing' ? <span className="text-brand">Running</span> : 
             <span className="text-gray-400">Waiting</span>}
          </div>
        </div>
      ))}
      <style>{`
        @keyframes loading {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(300%); }
        }
      `}</style>
    </div>
  );
};

export default ProcessingStepper;
