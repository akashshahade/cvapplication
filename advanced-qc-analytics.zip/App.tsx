
import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  Settings, 
  Moon,
  Sun,
  Menu,
  FileSpreadsheet,
  FileText,
  FlaskConical,
  X,
  ShieldCheck,
  Cpu,
  Clock,
  BarChart3,
  Network
} from 'lucide-react';
import { SpoutMetadata, PipelineStep, Metric } from './types';
import { PIPELINE_STEPS, generateRandomMetrics } from './constants';
import MetadataForm from './components/MetadataForm';
import ImageUpload from './components/ImageUpload';
import ProcessingStepper from './components/ProcessingStepper';
import ResultsDashboard from './components/ResultsDashboard';
import Sidebar from './components/Sidebar';
import { exportToPDF, exportToExcel } from './services/exportService';
import { getGeminiInsight } from './services/geminiService';

const App: React.FC = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [stage, setStage] = useState<'form' | 'upload' | 'processing' | 'results'>('form');
  const [activeModal, setActiveModal] = useState<'none' | 'thresholds' | 'releaseNotes' | 'modelHealth'>('none');
  const [metadata, setMetadata] = useState<SpoutMetadata>({
    serialNo: '',
    batchId: '',
    operator: '',
    scanDate: new Date().toISOString().split('T')[0]
  });
  const [files, setFiles] = useState<{ xray: File | null; ct: File | null }>({ xray: null, ct: null });
  const [pipelineSteps, setPipelineSteps] = useState<PipelineStep[]>(PIPELINE_STEPS);
  const [activeStep, setActiveStep] = useState(0);
  const [aiInsight, setAiInsight] = useState<string>('');
  const [currentMetrics, setCurrentMetrics] = useState<Metric[]>(generateRandomMetrics());
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const handleMetadataSubmit = (data: SpoutMetadata) => {
    setMetadata(data);
    setStage('upload');
  };

  const handleFileUpload = (type: 'xray' | 'ct', file: File | null) => {
    setFiles(prev => ({ ...prev, [type]: file }));
  };

  const startAnalysis = () => {
    setStage('processing');
    const newMetrics = generateRandomMetrics();
    setCurrentMetrics(newMetrics);
    let currentStep = 0;
    
    const interval = setInterval(() => {
      setPipelineSteps(prev => prev.map((step, idx) => {
        if (idx === currentStep) return { ...step, status: 'processing' };
        if (idx < currentStep) return { ...step, status: 'completed' };
        return step;
      }));
      
      setActiveStep(currentStep);
      
      if (currentStep >= PIPELINE_STEPS.length) {
        clearInterval(interval);
        setTimeout(() => {
          setStage('results');
          fetchGeminiInsight(newMetrics);
        }, 500);
      }
      currentStep++;
    }, 800);
  };

  const fetchGeminiInsight = async (metrics: Metric[]) => {
    const insight = await getGeminiInsight(metrics);
    setAiInsight(insight);
  };

  const resetApp = () => {
    setStage('form');
    setFiles({ xray: null, ct: null });
    setPipelineSteps(PIPELINE_STEPS.map(s => ({ ...s, status: 'pending' })));
    setAiInsight('');
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${isDarkMode ? 'bg-dark text-white' : 'bg-gray-50 text-gray-900'} flex`}>
      <Sidebar 
        isOpen={isSidebarOpen} 
        toggle={() => setIsSidebarOpen(!isSidebarOpen)}
        currentStage={stage}
        onReset={resetApp}
        onOpenThresholds={() => setActiveModal('thresholds')}
        onOpenReleaseNotes={() => setActiveModal('releaseNotes')}
        onOpenModelHealth={() => setActiveModal('modelHealth')}
      />

      <div className="flex-1 flex flex-col min-w-0">
        <header className={`sticky top-0 z-30 px-6 py-4 flex items-center justify-between border-b ${isDarkMode ? 'bg-dark-lighter border-gray-800' : 'bg-white border-gray-200'}`}>
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)} 
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors md:hidden"
            >
              <Menu size={20} />
            </button>
            <div className="flex items-center gap-2">
              <div className="bg-brand p-1.5 rounded-lg">
                <Activity className="text-white" size={24} />
              </div>
              <h1 className="text-xl font-bold tracking-tight dark:text-white">SpoutAI</h1>
            </div>
            <div className="hidden md:flex h-6 w-px bg-gray-300 dark:bg-gray-700 mx-4" />
            <span className="hidden md:inline text-sm font-medium text-gray-500 dark:text-gray-300">
              {stage === 'form' && 'Metadata Configuration'}
              {stage === 'upload' && 'Resource Ingestion'}
              {stage === 'processing' && 'AI Pipeline Execution'}
              {stage === 'results' && 'Inspection Intelligence'}
            </span>
          </div>

          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            >
              {isDarkMode ? <Sun size={20} className="text-yellow-400" /> : <Moon size={20} className="text-gray-600" />}
            </button>
            {stage === 'results' && (
              <div className="flex gap-2">
                <button 
                  onClick={() => exportToExcel(metadata, currentMetrics)}
                  className="flex items-center gap-2 px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white rounded-md text-sm font-medium transition-colors"
                >
                  <FileSpreadsheet size={16} /> <span className="hidden sm:inline">Excel</span>
                </button>
                <button 
                  onClick={() => exportToPDF(metadata, currentMetrics)}
                  className="flex items-center gap-2 px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-md text-sm font-medium transition-colors"
                >
                  <FileText size={16} /> <span className="hidden sm:inline">PDF</span>
                </button>
              </div>
            )}
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-6 lg:p-10 max-w-7xl mx-auto w-full">
          {stage === 'form' && (
            <div className="max-w-2xl mx-auto animate-fadeIn">
              <div className="mb-8 text-center">
                <h2 className="text-3xl font-bold mb-2 dark:text-white">Welcome to SpoutAI</h2>
                <p className="text-gray-500 dark:text-gray-300">Please enter the inspection metadata to begin the QC process.</p>
              </div>
              <MetadataForm initialData={metadata} onSubmit={handleMetadataSubmit} />
            </div>
          )}

          {stage === 'upload' && (
            <div className="max-w-4xl mx-auto animate-fadeIn">
              <div className="mb-8">
                <button 
                  onClick={() => setStage('form')} 
                  className="text-brand flex items-center gap-1 text-sm font-medium hover:underline mb-4"
                >
                  ← Back to Metadata
                </button>
                <h2 className="text-2xl font-bold dark:text-white">Upload Scan Data</h2>
                <p className="text-gray-500 dark:text-gray-300">Provide high-resolution X-ray and CT scans for analysis.</p>
              </div>
              <ImageUpload 
                onUpload={handleFileUpload} 
                files={files} 
                onStartAnalysis={startAnalysis} 
              />
            </div>
          )}

          {stage === 'processing' && (
            <div className="max-w-3xl mx-auto animate-fadeIn">
              <div className="mb-12 text-center">
                <FlaskConical className="mx-auto text-brand mb-4 animate-bounce" size={48} />
                <h2 className="text-2xl font-bold dark:text-white">Analyzing Spout Data...</h2>
                <p className="text-gray-500 dark:text-gray-300">Executing machine learning models and computer vision pipelines.</p>
              </div>
              <ProcessingStepper steps={pipelineSteps} activeIndex={activeStep} />
            </div>
          )}

          {stage === 'results' && (
            <div className="animate-fadeIn">
              <ResultsDashboard 
                metadata={metadata} 
                metrics={currentMetrics} 
                aiInsight={aiInsight}
              />
            </div>
          )}
        </main>

        <footer className={`py-6 px-10 text-center text-sm ${isDarkMode ? 'text-gray-400 bg-dark-lighter border-t border-gray-800' : 'text-gray-400 bg-white border-t border-gray-100'}`}>
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p>© 2026 SpoutAI. All rights reserved.</p>
            <div className="flex gap-4">
              <span className="flex items-center gap-1">Developed by <b>Akash Shahade</b> & <b>Nikhil Pingale</b></span>
            </div>
          </div>
        </footer>
      </div>

      {activeModal !== 'none' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fadeIn">
          <div className={`w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden ${isDarkMode ? 'bg-dark-lighter border border-gray-800 text-white' : 'bg-white'}`}>
            <div className="flex items-center justify-between p-6 border-b dark:border-gray-800">
              <h3 className="text-xl font-bold">
                {activeModal === 'thresholds' ? 'Threshold Configuration' : 
                 activeModal === 'releaseNotes' ? 'Release Notes' : 'Model Health Diagnostics'}
              </h3>
              <button onClick={() => setActiveModal('none')} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full">
                <X size={20} />
              </button>
            </div>
            <div className="p-6 max-h-[70vh] overflow-y-auto">
              {activeModal === 'thresholds' ? (
                <div className="space-y-4">
                  <p className="text-sm text-gray-500 dark:text-gray-300 mb-4">Set global PASS/FAIL thresholds for inspection parameters.</p>
                  {[
                    { label: 'Max Crack Length', value: '2.0', unit: 'mm' },
                    { label: 'Max Crack Width', value: '0.25', unit: 'mm' },
                    { label: 'Porosity Volume Fraction', value: '3.0', unit: '%' },
                    { label: 'Max Pore Diameter', value: '0.50', unit: 'mm' },
                    { label: 'Mesh Axis Tilt', value: '3.0', unit: '°' },
                    { label: 'Confidence Score', value: '80.0', unit: '%' },
                  ].map((t) => (
                    <div key={t.label} className="flex items-center justify-between gap-4">
                      <label className="text-sm font-medium">{t.label}</label>
                      <div className="flex items-center gap-2">
                        <input 
                          type="number" 
                          defaultValue={t.value} 
                          className="w-24 px-3 py-1.5 border rounded-lg dark:bg-gray-800 dark:border-gray-700 text-sm dark:text-white"
                        />
                        <span className="text-xs text-gray-400 w-8">{t.unit}</span>
                      </div>
                    </div>
                  ))}
                  <button onClick={() => setActiveModal('none')} className="w-full mt-6 py-3 bg-brand text-white rounded-xl font-bold hover:bg-blue-600 transition-colors">
                    Save Changes
                  </button>
                </div>
              ) : activeModal === 'modelHealth' ? (
                <div className="space-y-6">
                   <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl border dark:border-gray-700">
                         <div className="flex items-center gap-2 text-brand mb-2">
                            <Clock size={16} />
                            <span className="text-xs font-bold uppercase">Latency</span>
                         </div>
                         <p className="text-2xl font-black">42ms</p>
                         <p className="text-[10px] text-green-500 font-bold mt-1 flex items-center gap-1">
                            <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" /> Optimal
                         </p>
                      </div>
                      <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl border dark:border-gray-700">
                         <div className="flex items-center gap-2 text-brand mb-2">
                            <Cpu size={16} />
                            <span className="text-xs font-bold uppercase">GPU Load</span>
                         </div>
                         <p className="text-2xl font-black">14%</p>
                         <p className="text-[10px] text-green-500 font-bold mt-1">Idle / Ready</p>
                      </div>
                      <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl border dark:border-gray-700">
                         <div className="flex items-center gap-2 text-brand mb-2">
                            <Network size={16} />
                            <span className="text-xs font-bold uppercase">Drift</span>
                         </div>
                         <p className="text-2xl font-black">0.02%</p>
                         <p className="text-[10px] text-blue-500 font-bold mt-1">Negligible</p>
                      </div>
                      <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl border dark:border-gray-700">
                         <div className="flex items-center gap-2 text-brand mb-2">
                            <ShieldCheck size={16} />
                            <span className="text-xs font-bold uppercase">Uptime</span>
                         </div>
                         <p className="text-2xl font-black">99.9%</p>
                         <p className="text-[10px] text-green-500 font-bold mt-1">Service Online</p>
                      </div>
                   </div>
                   <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-100 dark:border-blue-900/30">
                      <div className="flex items-center gap-2 mb-2 font-bold text-sm">
                         <BarChart3 size={16} /> Inference Statistics
                      </div>
                      <div className="space-y-2 text-xs">
                         <div className="flex justify-between"><span>Total Scans Today</span><span>142</span></div>
                         <div className="flex justify-between"><span>False Positive Rate</span><span>0.12%</span></div>
                         <div className="flex justify-between"><span>Model Version</span><span>v2.5-flash-native</span></div>
                      </div>
                   </div>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="border-l-4 border-brand pl-4">
                    <h4 className="font-bold text-lg">v1.0 MVP Launch</h4>
                    <p className="text-xs text-gray-400">February 2026</p>
                    <ul className="mt-3 space-y-2 text-sm text-gray-600 dark:text-gray-300">
                      <li>• Automated 3D Porosity Analysis pipeline</li>
                      <li>• Dual-modality image ingestion (X-ray + CT)</li>
                      <li>• Real-time AI processing stepper</li>
                      <li>• Interactive results dashboard with Recharts</li>
                      <li>• Multi-format report export (PDF & Excel)</li>
                      <li>• Dark mode UI architecture</li>
                    </ul>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
