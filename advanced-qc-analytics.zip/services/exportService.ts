
import { SpoutMetadata, Metric } from '../types';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';

/**
 * Service to handle PDF and Excel exports.
 */

export const exportToPDF = (metadata: SpoutMetadata, metrics: Metric[]) => {
  const doc = new jsPDF();
  const timestamp = new Date().toLocaleString();
  
  // Header background
  doc.setFillColor(0, 122, 194); // Eaton Blue (#007AC2)
  doc.rect(0, 0, 210, 45, 'F');
  
  // Title
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(22);
  doc.text('SpoutAI Inspection Intelligence', 15, 25);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Generated: ${timestamp}`, 15, 35);
  doc.text(`System Version: 1.0 MVP`, 15, 40);

  // Metadata Section
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('Inspection Metadata', 15, 60);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Serial Number: ${metadata.serialNo}`, 15, 70);
  doc.text(`Batch ID: ${metadata.batchId}`, 15, 76);
  doc.text(`Lead Operator: ${metadata.operator}`, 15, 82);
  doc.text(`Scan Date: ${metadata.scanDate}`, 15, 88);

  // Metrics Table
  autoTable(doc, {
    startY: 100,
    head: [['Inspection Parameter', 'Measured Value', 'Safety Threshold', 'Verdict', 'Severity']],
    body: metrics.map(m => [
      m.parameter, 
      m.measured, 
      m.threshold, 
      m.status,
      m.severity
    ]),
    theme: 'striped',
    headStyles: { 
      fillColor: [0, 122, 194], 
      textColor: [255, 255, 255],
      fontStyle: 'bold'
    },
    columnStyles: {
      3: { fontStyle: 'bold' } // Verdict column
    },
    didParseCell: (data) => {
      if (data.section === 'body' && data.column.index === 3) {
        if (data.cell.raw === 'FAIL') {
          data.cell.styles.textColor = [220, 38, 38]; // Red
        } else {
          data.cell.styles.textColor = [22, 163, 74]; // Green
        }
      }
    }
  });

  // Summary Footer
  const finalY = (doc as any).lastAutoTable.finalY || 200;
  const isPass = metrics.every(m => m.status === 'PASS');
  
  doc.setFillColor(isPass ? 240 : 254, isPass ? 253 : 242, isPass ? 244 : 242);
  doc.rect(15, finalY + 10, 180, 25, 'F');
  
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(isPass ? [22, 163, 74] : [220, 38, 38]);
  doc.text(`OVERALL VERDICT: ${isPass ? 'PASS' : 'FAIL'}`, 25, finalY + 27);
  
  doc.setFontSize(9);
  doc.setTextColor(100, 100, 100);
  doc.text('Note: This is an AI-generated report for demo purposes.', 15, finalY + 45);

  doc.save(`SpoutAI_Inspection_${metadata.serialNo}_${Date.now()}.pdf`);
};

export const exportToExcel = (metadata: SpoutMetadata, metrics: Metric[]) => {
  const metaSheet = XLSX.utils.json_to_sheet([metadata]);
  const metricsSheet = XLSX.utils.json_to_sheet(metrics.map(m => ({
    Parameter: m.parameter,
    Measured: m.measured,
    Threshold: m.threshold,
    Status: m.status,
    Severity: m.severity
  })));

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, metaSheet, "Metadata");
  XLSX.utils.book_append_sheet(wb, metricsSheet, "Analysis Results");

  XLSX.writeFile(wb, `SpoutAI_Results_${metadata.serialNo}.xlsx`);
};
