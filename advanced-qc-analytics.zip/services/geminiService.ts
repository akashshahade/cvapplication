
import { GoogleGenAI } from "@google/genai";
import { Metric } from '../types';

export const getGeminiInsight = async (metrics: Metric[]): Promise<string> => {
  if (!process.env.API_KEY) {
    return "AI-driven summary unavailable without API key. Please check the results table for details.";
  }

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const metricStr = metrics.map(m => `${m.parameter}: ${m.measured} (Status: ${m.status}, Severity: ${m.severity})`).join('\n');
    
    const prompt = `
      You are an expert Quality Control Engineer specializing in epoxy-cast electrical insulators.
      Analyze the following inspection data and provide a professional, concise summary (approx 3-4 sentences).
      
      Metrics Data:
      ${metricStr}
      
      Include:
      1. Identification of the main reason for failure (if applicable).
      2. Assessment of the overall structural integrity.
      3. A recommendation for the next step (e.g., scrap, rework, or use as-is).
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text || "Insight generation timed out.";
  } catch (error) {
    console.error("Gemini Insight Error:", error);
    return "The AI pipeline completed, but the natural language insight failed to generate. See metric breakdown for verdict.";
  }
};
